//
//  ViewController.m
//  kbTest
//
//  Created by zk on 16/2/28.
//  Copyright © 2016年 zkr. All rights reserved.
//



#import "ViewController.h"
#import "WebViewController.h"

@interface ViewController () <UITextFieldDelegate>
@property (nonatomic, strong) IBOutlet UITextField *textField;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)HandleUrlCall:(id)sender
{
    WebViewController *vc = [[WebViewController alloc] init];
    vc.view.frame = [UIScreen mainScreen].bounds;
    //[vc loadUrl: @"http://99.12.74.148/netpayment/mbpay/MBPayTest_Dev.html"];
    
    NSString *getURL = _textField.text;
    if ([_textField.text hasPrefix:@"http"] == NO) {//考虑输入的网 址中不是以http开头的情况
        getURL =[ @"http://" stringByAppendingString:_textField.text];
    }
    [vc loadUrl:getURL];
    
    [self.navigationController pushViewController:vc animated:YES];
}


#pragma mark - UITextFied delegate
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    
    textField.clearsOnBeginEditing = YES;
    
    return YES;
    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    
    textField.keyboardType = UIKeyboardTypeDefault;
    //设置初始
    if ([textField.text length] > 0) {
        //[keyboard setArrayBufferWithString:textField.text];
    }
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    
    return YES;
}


@end
