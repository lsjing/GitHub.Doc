//
//  CMBWebViewController.h
//  SKeyboardDemo
//
//  Created by zk on 15/12/2.
//  Copyright © 2015年 zk. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WebViewController : UIViewController 
- (void)loadUrl:(NSString*)outerURL;
- (void)loadURLRequest:(NSURLRequest*)requesturl;
@end
