﻿using System;

namespace Aop.Api
{
    /// <summary>
    /// 基础对象。
    /// </summary>
    [Serializable]
    public abstract class AopObject
    {
    }
}
