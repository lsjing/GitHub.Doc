/** Automatically generated file. DO NOT MODIFY */
package com.alipay.android.app.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}