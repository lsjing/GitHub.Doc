package com.alipay.sdk.auth.demo;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.alipay.android.app.demo.R;
import com.alipay.android.app.pay.AuthTask;
import com.alipay.android.app.pay.AuthTask.OnAuthListener;
import com.alipay.sdk.pay.demo.SignUtils;

public class AuthDemoActivity extends Activity {

	//商户PID
	public static final String PARTNER = "";
	//商户收款账号
	public static final String SELLER = "";
	//商户私钥，pkcs8格式
	public static final String RSA_PRIVATE = "";
	//支付宝公钥
	public static final String RSA_PUBLIC = "";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.auth_layout);
	}

	@Override
	protected void onActivityResult(int requestCode, int result, Intent data) {
		super.onActivityResult(requestCode, result, data);

		// 使用intent 方式调用支付，处理支付结果
		String resultStatus = data.getStringExtra("resultStatus");
		String memo = data.getStringExtra("memo");
		
		// 支付宝返回此次授权结果及加签，建议对支付宝签名信息拿签约时支付宝提供的公钥做验签
		String resultInfo = data.getStringExtra("result");

		// 判断resultStatus 为“9000”且result_code 为“200”则代表授权成功，具体状态码代表含义可参考授权接口文档
		AuthResult authResult = new AuthResult(resultInfo);
		if (TextUtils.equals(resultStatus, "9000") && TextUtils.equals(authResult.getResultCode(), "200")) {
			// 获取alipay_open_id，调支付时作为参数extern_token 的value 传入，则用户使用的支付账户为该授权账户
			Toast.makeText(AuthDemoActivity.this,
					"授权成功\n" + authResult.getAlipayOpenId(), Toast.LENGTH_SHORT)
					.show();
		} else {
			// 其他状态值则为授权失败
			Toast.makeText(AuthDemoActivity.this, "授权失败", Toast.LENGTH_SHORT)
					.show();
		}
	}

	public void auth(View v) {
		// 授权信息
		String info = getAuthInfo();
		// 对授权信息做签名
		String sign = sign(info);
		try {
			// 仅需对sign 做URL编码
			sign = URLEncoder.encode(sign, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		// 完整的符合支付宝授权规范的参数信息
		final String authInfo = info + "&sign=\"" + sign + "\"&"
				+ getSignType();

		// 使用AuthTask 对象调用授权，授权结果在OnAuthListener 回调接口处理
		AuthTask authTask = new AuthTask(this, new OnAuthListener() {

			@Override
			public void onAuthSuccess(Context context, String resultStatus,
					String memo, String result) {
				// 处理授权成功
				AuthResult authResult = new AuthResult(result);
				if (TextUtils.equals(authResult.getResultCode(), "200")) {
					// 获取alipay_open_id，调支付时作为参数extern_token 的value 传入，则支付账户为该授权账户
					Toast.makeText(AuthDemoActivity.this,
							"授权成功\n" + authResult.getAlipayOpenId(),
							Toast.LENGTH_SHORT).show();
				}
			}

			@Override
			public void onAuthFailed(Context context, String resultStatus,
					String memo, String result) {
				// 处理授权失败
				Toast.makeText(AuthDemoActivity.this, "授权失败",
						Toast.LENGTH_SHORT).show();
			}
		});
		 authTask.auth(authInfo);

		// 使用intent 调用授权，支付结果在onActivityResult 函数处理
//		Intent intent = new Intent();
//		intent.setPackage(getPackageName());
//		intent.setAction("com.alipay.mobilepay.android");
//		intent.putExtra("auth_info", authInfo);
//		startActivityForResult(intent, 0);
	}

	private String getAuthInfo() {
		EditText appId = (EditText) findViewById(R.id.app_id);
		EditText pId = (EditText) findViewById(R.id.pid);
		EditText targetId = (EditText) findViewById(R.id.target_id);

		String app_id = appId.getText().toString();
		String pid = pId.getText().toString();
		String target_id = targetId.getText().toString();

		// 服务接口名称， 固定值
		String authInfo = "apiname=\"com.alipay.account.auth\"";

		// 商户签约拿到的app_id，如：2013081700024223
		authInfo += "&app_id=" + "\"" + app_id + "\"";

		// 商户类型标识， 固定值
		authInfo += "&app_name=\"mc\"";

		// 授权类型，授权常量值为"AUTHACCOUNT", 登录常量值为"LOGIN" 
		authInfo += "&auth_type=\"AUTHACCOUNT\"";

		// 业务类型， 固定值
		authInfo += "&biz_type=\"openservice\"";

		// 商户签约拿到的pid，如：2088102123816631
		authInfo += "&pid=" + "\"" + pid + "\"";

		// 产品码， 固定值
		authInfo += "&product_id=\"WAP_FAST_LOGIN\"";

		// 授权范围， 固定值
		authInfo += "&scope=\"kuaijie\"";

		// 商户唯一标识，如：kkkkk091125
		authInfo += "&target_id=" + "\"" + target_id + "\"";

		// 签名时间戳
		authInfo += "&sign_date=" + "\"" + getSignDate() + "\"";

		return authInfo;

	}

	/**
	 * sign the order info. 对授权信息进行签名
	 * 
	 * @param content
	 *            待签名授权信息
	 */
	public String sign(String content) {
		return SignUtils.sign(content, RSA_PRIVATE);
	}

	/**
	 * get the sign type we use. 获取签名方式
	 * 
	 */
	public String getSignType() {
		return "sign_type=\"RSA\"";
	}

	/**
	 * get the sign time. 获取当前签名时间
	 * 
	 */
	private String getSignDate() {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
				Locale.getDefault());
		return format.format(new Date());
	}
}
